# How to Fly the Helicopter - Controls Guide

## Starting the Game

```bash
cd /home/ashokt4/Desktop/BR/helicopter-game-master
./build/3DOpenGL
```

A window will open with a white background and a 3D helicopter in the center.

---

## Flight Controls

### **Engine & Vertical Movement**

| Key | Action |
|-----|--------|
| **P** | Toggle Engine ON/OFF (press once to start, again to stop) |
| **Y** | Climb UP (increase altitude) |
| **I** | Descend DOWN (decrease altitude) |

**How to take off:**
1. Press **P** to turn the engine ON
2. Press **Y** to climb upward
3. The helicopter will start ascending

### **Horizontal Movement (Left/Right, Forward/Backward)**

| Key | Action |
|-----|--------|
| **U** | Move FORWARD |
| **J** | Move BACKWARD |
| **H** | Rotate LEFT (turn left) |
| **K** | Rotate RIGHT (turn right) |

### **Combat & Effects**

| Key | Action |
|-----|--------|
| **SPACEBAR** | Shoot bullets at UFOs |
| **X** | Create smoke screen (defensive move) |

### **Camera Views**

| Key | Action |
|-----|--------|
| **V** | Switch to next camera view |
| **C** | Switch to previous camera view |

There are **3 camera angles** you can cycle through.

---

## Basic Flight Tutorial

### Step 1: Take Off
```
Press P → Engine starts (rotors spinning)
Press Y repeatedly → Helicopter rises into the air
```

### Step 2: Move Around
```
Press U → Move forward
Press H or K → Turn left or right
Press J → Move backward
Press I → Descend lower
```

### Step 3: Combat
```
Aim at UFOs using camera views (V/C)
Press SPACEBAR → Fire bullets
UFOs will try to attack - use X for smoke screen to escape
```

### Step 4: Land
```
Press I → Descend
Press P → Turn off engine
Helicopter lands safely
```

---

## Tips for Flying

✈️ **Smooth Flying:**
- Use **Y** and **I** gently to control altitude
- Use **U** and **J** carefully for forward/backward movement
- Combine **H/K** rotation with **U/J** movement for diagonal flying

🎯 **Combat Tips:**
- Switch cameras with **V/C** to get better angles on UFOs
- Use **X** (smoke screen) when UFOs get close
- Shoot with **SPACEBAR** in bursts
- Each UFO you destroy gets harder - they spawn faster

🛫 **Takeoff Checklist:**
1. ✅ Press **P** (engine on)
2. ✅ Press **Y** (climb)
3. ✅ Wait for altitude to increase
4. ✅ Use **H/K** to control direction

🛬 **Landing Checklist:**
1. ✅ Press **I** to descend slowly
2. ✅ Level out (stop pressing keys)
3. ✅ Press **P** to turn off engine

---

## Full Keyboard Map

```
        Y (Climb)
        │
  H ← ┌─┴─┐ → K (Rotate Right)
(Left)│   │(Turn Left)
      │ P │ (Engine ON/OFF)
  U ─→│   │ ← J (Backward)
(Forward)│ I │
      └───┘ (Descend)
        │
        I (Descend)

SPACEBAR = Shoot
X = Smoke Screen
V/C = Change Camera
```

---

## Game Objective

🎮 **Destroy as many UFOs as possible without getting hit!**

- Incoming UFOs spawn every few seconds
- Each UFO you destroy increases difficulty
- UFOs move faster and spawn more frequently as you progress
- Use your helicopter's agility and camera views to outmaneuver enemies
- Smoke screen is your defensive tool when overwhelmed

---

## Troubleshooting

**Helicopter won't move:**
- Make sure engine is ON (press **P** first)
- Check if you're pressing the right keys (U/J/H/K)

**Can't see the helicopter:**
- Press **V** or **C** to switch camera views
- Default camera looks from behind the helicopter

**UFOs too fast:**
- Use smoke screen (**X**) to create distance
- Rotate (**H/K**) quickly to change direction
- Climb or descend (**Y/I**) to avoid collisions

---

## Enjoy Flying! 🚁
