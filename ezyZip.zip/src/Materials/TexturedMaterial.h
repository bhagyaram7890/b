//
// Created by Ned on 5/14/2016.
//

#ifndef INC_3DOPENGL_TEXTUREDMATERIAL_H
#define INC_3DOPENGL_TEXTUREDMATERIAL_H


#include <GL/gl.h>
#include <stddef.h>
#include "Material.h"
#include "../Objects/General/Object.h"
#include "../Utility/Resource.h"
#include <string>
#include <cstdlib>

extern "C" unsigned char *stbi_load(char const *filename, int *e, int *y, int *comp, int req_comp);

class TexturedMaterial : public Material {
    GLuint texture;
    bool alpha = false;
public:
    TexturedMaterial(const char *imageName, GLint filtering = GL_LINEAR_MIPMAP_LINEAR) {
        // Convert path to include res/ prefix if needed
        std::string fullPath = resPath(imageName);
        
        unsigned char *data;
        int width;
        int height;
        int nComponents = 4;
        data = stbi_load(fullPath.c_str(), &width, &height, &nComponents, 0);
        if (data == NULL) {
            printf("WARNING: Texture %s not found (tried: %s)\n", imageName, fullPath.c_str());
            return;
        }

        glGenTextures(1, &texture);
        glBindTexture(GL_TEXTURE_2D, texture);

        if (nComponents == 4) {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
            alpha = true;
        } else if (nComponents == 3) {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
            alpha = false;
        }
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    // stbi_load allocates with malloc-like allocator; free the buffer
    free(data);
    }

    void apply() {
        Material::apply();
        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, texture);
    }

    bool hasAlpha() const { return alpha; }
};


#endif //INC_3DOPENGL_TEXTUREDMATERIAL_H
