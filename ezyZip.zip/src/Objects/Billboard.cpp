//
// Created by Ned on 5/14/2016.
//

#include <stdio.h>
#include "Billboard.h"
#include "../Materials/TexturedMaterial.h"

void Billboard::draw(Camera &camera) {
    glDisable(GL_LIGHTING);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glDepthMask(GL_FALSE);

    // Apply material (may enable texturing)
    material->apply();

    // If the textured material has no alpha channel, draw a dark filled quad
    // instead of texturing it (avoids visible white-background boxes).
    TexturedMaterial *tm = dynamic_cast<TexturedMaterial *>(material);

    glPushMatrix();
    {
        glTranslatef(position.x, position.y, position.z);
        glScalef(scaleFactor.x, scaleFactor.y, scaleFactor.z);
        float camRotation[] = {
                camera.right.x, camera.right.y, camera.right.z, 0,
                camera.up.x, camera.up.y, camera.up.z, 0,
                camera.ahead.x, camera.ahead.y, camera.ahead.z, 0,
                0, 0, 0, 1
        };
        glMultMatrixf(camRotation);

    if (!tm || !tm->hasAlpha()) {
            // render a small dark 'bullet' quad when texture has no alpha
            glDisable(GL_TEXTURE_2D);
            glColor4d(0.05, 0.05, 0.05, transparency);
            glBegin(GL_QUADS);
            glVertex3d(-1, -1, 0);
            glVertex3d(1, -1, 0);
            glVertex3d(1, 1, 0);
            glVertex3d(-1, 1, 0);
            glEnd();
            glEnable(GL_TEXTURE_2D);
        } else {
            glColor4d(1, 1, 1, transparency);
            glBegin(GL_QUADS);
            {
                glTexCoord3d(0, 0, 0);
                glVertex3d(-1, -1, 0);

                glTexCoord3d(1, 0, 0);
                glVertex3d(1, -1, 0);

                glTexCoord3d(1, 1, 0);
                glVertex3d(1, 1, 0);

                glTexCoord3d(0, 1, 0);
                glVertex3d(-1, 1, 0);
            }
            glEnd();
        }
    }
    glPopMatrix();

    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    glEnable(GL_LIGHTING);
}

bool Billboard::move(double t, double dt) {
    translate(velocity * dt);
    if(liveForever)
        return false;
    age(dt);
    if(lifeSpan < fadeOut) {
        transparency = lifeSpan / fadeOut;
    }
    return !isAlive();
}

Billboard *Billboard::scale(float3 factor) {
    scaleFactor *= factor;
    return this;
}

Billboard *Billboard::translate(float3 offset) {
    position += offset;
    return this;
}