//
// Created by Ned on 5/14/2016.
//

#include "MeshInstance.h"

void MeshInstance::drawModel() {
    mesh->draw();
}