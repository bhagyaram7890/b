//
// Created by Ned on 5/14/2016.
//

#include "Teapot.h"

void Teapot::drawModel() {
    glutSolidTeapot(1.0f);
}