// Minimal PlaySound declaration + flags for cross-platform compatibility
#ifndef INC_3DOPENGL_AUDIO_H
#define INC_3DOPENGL_AUDIO_H

#include <stddef.h>

// PlaySound flags (subset used by the project)
#define SND_SYNC   0x0000
#define SND_ASYNC  0x0001
#define SND_NODEFAULT 0x0002
#define SND_LOOP   0x0008
#define SND_FILENAME 0x20000

// TEXT macro for compatibility with Windows TEXT() wide-string macro; project uses narrow strings
#define TEXT(x) x

extern "C" int PlaySound(const char *pszSound, void *hmod, unsigned int fdwSound);

#endif // INC_3DOPENGL_AUDIO_H
