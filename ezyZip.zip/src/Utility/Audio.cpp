// Lightweight PlaySound fallback for Linux/macOS: attempts to use aplay or paplay.
#include "Audio.h"
#include <string>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <stdio.h>

#if !defined(_WIN32) && !defined(WIN32) && !defined(__WIN32__)

static pid_t g_async_pid = 0;

static const char *find_player() {
    // prefer aplay (ALSA), then paplay (PulseAudio)
    if (access("/usr/bin/aplay", X_OK) == 0) return "aplay";
    if (access("/usr/bin/paplay", X_OK) == 0) return "paplay";
    // fallback to PATH lookup
    if (access("/bin/aplay", X_OK) == 0) return "aplay";
    return NULL;
}

extern "C" int PlaySound(const char *pszSound, void * /*hmod*/, unsigned int fdwSound) {
    if (!pszSound) {
        // stop any async sound
        if (g_async_pid > 0) {
            kill(g_async_pid, SIGTERM);
            int status = 0;
            waitpid(g_async_pid, &status, 0);
            g_async_pid = 0;
        }
        return 1;
    }

    const char *player = find_player();

    bool async = (fdwSound & SND_ASYNC) != 0;
    bool loop = (fdwSound & SND_LOOP) != 0;

    // If no player available, try generic aplay
    if (!player) {
        player = "aplay";
    }

    // Construct command
    char cmd_buf[512];
    if (loop) {
        snprintf(cmd_buf, sizeof(cmd_buf), "while true; do %s \"%s\" 2>/dev/null; done", player, pszSound);
    } else {
        snprintf(cmd_buf, sizeof(cmd_buf), "%s \"%s\" 2>/dev/null", player, pszSound);
    }

    if (async) {
        pid_t pid = fork();
        if (pid == 0) {
            // Child process
            if (loop) {
                execl("/bin/sh", "sh", "-c", cmd_buf, (char *)NULL);
            } else {
                execlp(player, player, pszSound, (char *)NULL);
            }
            _exit(127);
        } else if (pid > 0) {
            g_async_pid = pid;
            return 1;
        }
        return 0;
    } else {
        // Sync play
        if (loop) {
            // For sync with loop, just play once (looping would block forever)
            pid_t pid = fork();
            if (pid == 0) {
                execlp(player, player, pszSound, (char *)NULL);
                _exit(127);
            }
            int rc = 0;
            waitpid(pid, &rc, 0);
            return rc == 0;
        } else {
            pid_t pid = fork();
            if (pid == 0) {
                execlp(player, player, pszSound, (char *)NULL);
                _exit(127);
            }
            int rc = 0;
            waitpid(pid, &rc, 0);
            return rc == 0;
        }
    }
}

#endif
