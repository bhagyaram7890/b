// Simple helper to resolve resource paths so the program can run from build/ or project root.
#ifndef INC_3DOPENGL_RESOURCE_H
#define INC_3DOPENGL_RESOURCE_H

#include <string>
#include <unistd.h>
#include <vector>

inline std::string resPath(const std::string &name) {
	// Candidate directories (order matters)
	static const std::vector<std::string> candidates = {"res/", "../res/", "./res/", "../../res/"};
	for (const auto &c : candidates) {
		std::string p = c + name;
		if (access(p.c_str(), R_OK) == 0) return p;
	}
	// Fallback: return res/name (may still fail, caller handles)
	return std::string("res/") + name;
}

inline std::string resPath(const char *name) {
	return resPath(std::string(name));
}

#endif // INC_3DOPENGL_RESOURCE_H
